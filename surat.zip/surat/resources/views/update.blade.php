<div class="p2">
    <div class="form-group">
        <label for="tanggal">Tanggal Surat :</label><br>
        <input type="date" id="tanggal" name="tanggal" required value="{{$surat->tanggal}}" autocomplete="off"><br>
    <div class="form-group">
        <label for="pengirim">Pengirim :</label><br>
        <input type="text" id="pengirim" name="pengirim" required value="{{$surat->pengirim}}" autocomplete="off"><br>
    <div class="form-group">
        <label for="penerima">Penerima :</label><br>
        <input type="text" id="penerima" name="penerima" required value="{{$surat->penerima}}" autocomplete="off"><br>
    <br>
    <div class="form-group">
        <label for="judulsurat">Judul Surat :</label><br>
        <input type="text" id="judulsurat" name="judulsurat" required value="{{$surat->judulsurat}}" autocomplete="off"><br>
    <br>
    <div class="form-group">
        <label for="isisurat">Masukan Isi Surat Anda :</label><br>
        <input type="text" id="isisurat" name="isisurat" style="height:120px; width:450px;" required value="{{$surat->isisurat}}" autocomplete="off"><br>
        <br>
    </div>
    <div class="form-group mt-5">
    <button class="btn btn-dark" onclick="update({{ $surat->id }})">Update Data</button>
    </div>
</div>
