<link rel = "stylesheet" type="text/css" href = "css/bootstrap.min.css">
<div class="card-body">
    <table class = "table table-bordered table-striped" border="1">

    <thead>
        <tr>

            <th>No Surat</th>
            <th style="height:60px; width:120px">Tanggal Surat</th>
            <th>Pengirim</th>
            <th>Penerima</th>
            <th style="height:60px; width:150px">Judul Surat</th>
            <th>Isi Surat</th>
            <th style="height:60px; width:180px">Opsi</th>
        </tr>
    </thead>
    <tbody>
     @foreach ($surat as $surat)
            <tr>
              <td>{{ $loop->iteration }}</td>
              <td>{{ $surat->tanggal }}</td>
              <td>{{ $surat->pengirim }}</td>
              <td>{{ $surat->penerima }}</td>
              <td>{{ $surat->judulsurat }}</td>
              <td>{{ $surat->isisurat }}</td>
              <td>
                  <button class="btn btn-info" onclick="show({{ $surat->id }})">Update</button>
                  <button class="btn btn-info" onclick="destroy({{ $surat->id }})">Delete</button>
              </td>
            </tr>
              @endforeach
    </tbody>
</table>
