<link rel = "stylesheet" type="text/css" href = "css/bootstrap.min.css">
<div class="card-body">
    <table class = "table table-bordered table-striped" border="1">

    <thead>
        <tr>

            <th>No Surat</th>
            <th style="height:60px; width:120px">Tanggal Surat</th>
            <th>Pengirim</th>
            <th>Penerima</th>
            <th style="height:60px; width:150px">Judul Surat</th>
            <th>Isi Surat</th>
            <th style="height:60px; width:180px">Opsi</th>
        </tr>
    </thead>
    <tbody>
     <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($surat->Tanggal); ?></td>
              <td><?php echo e($surat->pengirim); ?></td>
              <td><?php echo e($surat->penerima); ?></td>
              <td><?php echo e($surat->judulsurat); ?></td>
              <td><?php echo e($surat->isisurat); ?></td>
              <td>
                  <button class="btn btn-info" onclick="show(<?php echo e($surat->id); ?>)">Update</button>
                  <button class="btn btn-info" onclick="destroy(<?php echo e($surat->id); ?>)">Delete</button>
              </td>
            </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\ASUS\surat\resources\views/read.blade.php ENDPATH**/ ?>