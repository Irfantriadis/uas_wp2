<div class="p2">
  <div class="form-group">
    <label for="tanggal">Tanggal Surat :</label><br>
    <input type="date" id="tanggal" name="tanggal"><br>
    <div class="form-group">
    <label for="pengirim">Pengirim :</label><br>
    <input type="text" id="pengirim" name="pengirim"><br>
    <div class="form-group">
    <label for="penerima">Penerima :</label><br>
    <input type="text" id="penerima" name="penerima"><br>
    <br>
    <div class="form-group">
    <label for="judulsurat">Judul Surat :</label><br>
    <input type="text" id="judulsurat" name="judulsurat"><br>
    <br>
    <div class="form-group">
    <label for="isisurat">Masukan Isi Surat Anda :</label><br>
    <input type="text" id="isisurat" name="isisurat" style="height:120px; width:450px;"><br>
    <br>
    </div>
    <div class="form-group mt-5">
    <button class="btn btn-dark" onclick="store()">Tambah Data</button>
    </div>
</div>
<?php /**PATH C:\Users\ASUS\surat\resources\views/create.blade.php ENDPATH**/ ?>